# DO YOU LOVE ME?

Hello! This is a a project I created just for fun. This project is not perfect since Iam learning more about HTML, CSS, and JavaScript, so I would appreciate it if you give me some feedbacks! Have fun!;)

## HOW TO USE IT

1. You can clone or download this project and open the .html file with your browser
2. Enter your name in the input box and then click the button
3. The page will change and you will see a question with the options "Yes" and "No"
4. You can click the "No" option to see something unique happens but it is okay to click "Yes" too ;)

